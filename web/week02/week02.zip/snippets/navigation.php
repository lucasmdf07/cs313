<ul>
					<li>
						<img id='lucas' src="images/lucas.PNG" alt="" data-position="center center" width="200"
							height="auto" /></a>
					</li>
					<li><a href="#intro">ABOUT</a></li>
					<li><a href="#one">EXPERIENCE</a></li>
					<li><a href="#two">EDUCATION</a></li>
					<li><a href="#three">CONTACT</a></li>
					<li><a href="#four">ASSIGNMENTS</a></li>
					<li><a href="#intro">MY LIFE</a></li>
				</ul>